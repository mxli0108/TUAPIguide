var HKTSO_Intro = $("img[alt='TSO_IntroImage']")[0].src;
var HK_OpenApiUrl = $("img[alt='TSO_IntroImage']")[0].src.replace("TSO_IntroImage","TSO_OpenApiSpec");
var HKSequenceDiagram = $("img[alt='TSO_IntroImage']")[0].src.replace("TSO_IntroImage","TSO_SequenceDiagram");

$("#moduleTitle").text("TSO API Guide");
var currentDomain = window.location.protocol + "//" + window.location.hostname;
$("head").append("<script type='text/javascript' src = '"+ currentDomain + "/DEPortalV35R2/Static/js/rapidoc-min.js'>");
var rapidoc = "<rapi-doc id='rapidoc1' info-description-headings-in-navbar = 'true' default-schema-tab='example' regular-font='Open Sans' mono-font = 'Roboto Mono' show-header='false' render-style='read' schema-expand-level='2' schema-style='table' allow-authentication='false' regular-font='Open Sans' default-schema-tab='example' bg-color='#ffffff' text-color='' nav-bg-color='#0295BE' header-bg='#0295BE' nav-text-color='#fff' nav-hover-bg-color='#d9f2f9' nav-hover-text-color='#000' nav-accent-color='#FCD800' primary-color='#0295BE'></rapi-doc>";
var jsonUrl = HK_OpenApiUrl;
var versions = ["V1"];
jsonUrl = jsonUrl.replace("TSO_OpenApiSpec","TSO_OpenApiSpec"+versions[0]);
var versionHtml = "<slot name='header'><select style='float:right;width:60px;margin:0px 10px;' id='ddl_apispec'>";
versions.forEach(function(e,i){
	versionHtml = versionHtml + "<option>" + e + "</option>";
});
versionHtml = versionHtml + "</select><label style='float:right'>Select Version</label></slot>";
rapidoc = rapidoc.replace("</rapi-doc>",versionHtml+"</rapi-doc>");
$(".mainWrapper").html(rapidoc);

$("body").on("change","#ddl_apispec",function(e,i){
var v = $("#ddl_apispec option:selected").val();
var newUrl = HK_OpenApiUrl.replace("TSO_OpenApiSpec","TSO_OpenApiSpec"+v);
console.log(newUrl);
loadUrl(newUrl);
})
loadUrl(jsonUrl);

function loadUrl(jsonUrl){
	jQuery.get(jsonUrl, function(data) {
	   data = data.replace('<html><script>var a = ','');
	   data = data.replace('<\/script><\/html>','');
	   data = data.replace('{TSO_IntroImage}',HKTSO_Intro);
	   data = data.replace('{TSO_SequenceDiagram}',HKSequenceDiagram);
	   var objSpec = JSON.parse(data);
	   $("#rapidoc1")[0].loadSpec(objSpec);
	   
	   $("#navmenu2").hide();
	   $(".mainWrapper").css('padding-top','90px');
	   

	   var rapidoc_timer = setInterval(function(){
			
			
		$(document.querySelector('rapi-doc').shadowRoot.querySelector('#nav-bar-search').nextElementSibling).hide();
		document.querySelector('rapi-doc').shadowRoot.querySelector('api-request[path="/TU.DE.Pont/token"]').shadowRoot.querySelector('input[data-pname="password"]').setAttribute('type', 'password');
			if(document.querySelector('rapi-doc') && document.querySelector('rapi-doc').shadowRoot && document.querySelector('rapi-doc').shadowRoot.querySelector('api-request[path="/TU.DE.Pont/Applications#NewApplication/"]')){
				clearInterval(rapidoc_timer);
				var sections = document.querySelector('rapi-doc').shadowRoot.querySelectorAll('api-request');
				for(var i=0;i<sections.length;i++){
					var ele = sections[i].shadowRoot.querySelector('.authBtn');
					$(ele).off('click').on('click',{'section':sections[i]},function(event){
						if(document.querySelector('rapi-doc').shadowRoot.querySelector('api-request[path="/TU.DE.Pont/token"]').shadowRoot.querySelector('.token.string'))
						{
							var token = document.querySelector('rapi-doc').shadowRoot.querySelector('api-request[path="/TU.DE.Pont/token"]').shadowRoot.querySelector('.token.string').innerHTML;
							console.log(event.data.section);
							var control = event.data.section.shadowRoot.querySelector('input[data-pname=\"Authorization\"]');
							console.log(control);
							token = token.slice(1,-1);
							$(control).val("Bearer "+token);
						}
						else{
							alert("Error! Access Token is empty.\n\n Please generate using Get Token section above");
						}
					});
				}
			}
		},3000);
	});
}